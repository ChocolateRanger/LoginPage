import './App.css';
import LoginPage from './compoents/LoginPage';

function App() {
  return (
    <>
    <LoginPage/>
    </>
  );
}

export default App;
